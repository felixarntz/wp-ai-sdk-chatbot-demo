/**
 * Internal dependencies
 */
import { MessagePart } from '../../types';
import './style.scss';
export type MediaProps = {
    mimeType: string;
    src: string;
};
export type JsonTextareaProps = {
    data: unknown;
    label: string;
};
export type MessagePartsProps = {
    parts: MessagePart[];
};
/**
 * Renders formatted message parts.
 *
 * @since 0.1.0
 *
 * @param props - Component props.
 * @returns The component to be rendered.
 */
export default function MessageParts(props: MessagePartsProps): import("react").JSX.Element;
//# sourceMappingURL=message-parts.d.ts.map