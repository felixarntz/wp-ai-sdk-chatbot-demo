<?php

/**
 * REST API initialization for Abilities API.
 *
 * @package abilities-api
 * @since   0.1.0
 */
declare (strict_types=1);
namespace Felix_Arntz\WP_AI_SDK_Chatbot_Demo_Dependencies;

/**
 * Handles initialization of Abilities REST API endpoints.
 *
 * @since 0.1.0
 */
class WP_REST_Abilities_Init
{
    /**
     * Registers the REST API routes for abilities.
     *
     * @since 0.1.0
     */
    public static function register_routes(): void
    {
        require_once __DIR__ . '/endpoints/class-wp-rest-abilities-run-controller.php';
        require_once __DIR__ . '/endpoints/class-wp-rest-abilities-list-controller.php';
        $run_controller = new WP_REST_Abilities_Run_Controller();
        $run_controller->register_routes();
        $list_controller = new WP_REST_Abilities_List_Controller();
        $list_controller->register_routes();
    }
}
/**
 * Handles initialization of Abilities REST API endpoints.
 *
 * @since 0.1.0
 */
\class_alias('Felix_Arntz\WP_AI_SDK_Chatbot_Demo_Dependencies\WP_REST_Abilities_Init', 'WP_REST_Abilities_Init', \false);
add_action('rest_api_init', array('WP_REST_Abilities_Init', 'register_routes'));
