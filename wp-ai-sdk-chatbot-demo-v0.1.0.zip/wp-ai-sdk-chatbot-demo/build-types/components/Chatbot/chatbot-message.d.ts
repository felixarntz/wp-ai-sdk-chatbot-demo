import { ChatbotMessage as ChatbotMessageType } from '../../types';
type ChatbotMessageProps = {
    /**
     * The message content object.
     */
    content: ChatbotMessageType;
    /**
     * Whether the message is loading.
     */
    loading?: boolean;
};
/**
 * Renders a chatbot message.
 *
 * @since 0.1.0
 *
 * @param props - Component props.
 * @returns The component to be rendered.
 */
export default function ChatbotMessage(props: ChatbotMessageProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=chatbot-message.d.ts.map