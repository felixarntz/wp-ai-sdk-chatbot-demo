/**
 * Transforms an error object into a user-facing error message.
 *
 * @since 0.1.0
 *
 * @param error - The error to transform.
 * @returns The error message as a string.
 */
export default function errorToString(error: unknown): string;
//# sourceMappingURL=error-to-string.d.ts.map