type ChatbotHeaderProps = {
    /**
     * The route to use for fetching and sending messages.
     */
    messagesRoute: string;
    /**
     * Function to call when the history of messages is reset.
     */
    onReset?: () => void;
    /**
     * Function to call when the close button is clicked.
     */
    onClose: () => void;
};
/**
 * Renders the chatbot header.
 *
 * @since 0.1.0
 *
 * @param props - Component props.
 * @returns The component to be rendered.
 */
export default function ChatbotHeader(props: ChatbotHeaderProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=chatbot-header.d.ts.map