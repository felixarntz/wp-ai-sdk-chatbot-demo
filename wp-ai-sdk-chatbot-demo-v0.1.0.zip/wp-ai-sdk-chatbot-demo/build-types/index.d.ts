import type { ServerChatbotConfig } from './types';
/**
 * Initializes the app by loading the chatbot when the DOM is ready.
 *
 * @since 0.1.0
 *
 * @param config - The chatbot configuration from the server.
 */
export declare function loadChatbot(config: ServerChatbotConfig): void;
//# sourceMappingURL=index.d.ts.map