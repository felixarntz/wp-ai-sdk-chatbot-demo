/**
 * External dependencies
 */
import type { SVGProps } from 'react';
type UserIconProps = SVGProps<SVGSVGElement>;
/**
 * Renders the user icon.
 *
 * @since 0.1.0
 *
 * @param props - The component props.
 * @returns The component to be rendered.
 */
export default function UserIcon(props: UserIconProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=user-icon.d.ts.map