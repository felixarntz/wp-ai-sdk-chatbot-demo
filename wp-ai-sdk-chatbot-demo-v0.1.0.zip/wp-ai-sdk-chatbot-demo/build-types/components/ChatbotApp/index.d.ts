import './style.scss';
import type { ServerChatbotConfig } from '../../types';
type ChatbotAppProps = {
    serverChatbotConfig: ServerChatbotConfig;
};
/**
 * Renders the chatbot.
 *
 * @since 0.1.0
 *
 * @param props - Component props.
 * @returns The component to be rendered.
 */
export default function ChatbotApp(props: ChatbotAppProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=index.d.ts.map