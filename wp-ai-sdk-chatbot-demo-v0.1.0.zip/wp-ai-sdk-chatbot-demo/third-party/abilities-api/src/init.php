<?php

/**
 * Abilities API Library Initialization
 *
 * @package WordPress\AbilitiesAPI
 * @since 0.1.0
 */
declare (strict_types=1);
namespace Felix_Arntz\WP_AI_SDK_Chatbot_Demo_Dependencies;

// Require the classes if not using Composer autoloading
if (!\class_exists('Felix_Arntz\WP_AI_SDK_Chatbot_Demo_Dependencies\WordPress\AbilitiesAPI\WP_Ability')) {
    require_once __DIR__ . '/WP_Ability.php';
}
if (!\class_exists('Felix_Arntz\WP_AI_SDK_Chatbot_Demo_Dependencies\WordPress\AbilitiesAPI\WP_Abilities_Registry')) {
    require_once __DIR__ . '/WP_Abilities_Registry.php';
}
// Create class aliases for backward compatibility
if (!\class_exists('Felix_Arntz\WP_AI_SDK_Chatbot_Demo_Dependencies\WP_Ability')) {
    \class_alias('Felix_Arntz\WP_AI_SDK_Chatbot_Demo_Dependencies\WordPress\AbilitiesAPI\WP_Ability', 'Felix_Arntz\WP_AI_SDK_Chatbot_Demo_Dependencies\WP_Ability');
}
if (!\class_exists('Felix_Arntz\WP_AI_SDK_Chatbot_Demo_Dependencies\WP_Abilities_Registry')) {
    \class_alias('Felix_Arntz\WP_AI_SDK_Chatbot_Demo_Dependencies\WordPress\AbilitiesAPI\WP_Abilities_Registry', 'Felix_Arntz\WP_AI_SDK_Chatbot_Demo_Dependencies\WP_Abilities_Registry');
}
