/**
 * External dependencies
 */
import type { ReactNode } from 'react';
/**
 * Internal dependencies
 */
import type { ChatbotConfig } from './types';
type ChatbotConfigProviderProps = {
    config: ChatbotConfig;
    children: ReactNode;
};
/**
 * Provides the chatbot configuration to child components.
 *
 * @since 0.1.0
 *
 * @param props - Component props.
 * @returns The component to be rendered.
 */
export declare function ChatbotConfigProvider(props: ChatbotConfigProviderProps): import("react").JSX.Element;
/**
 * A hook that returns a value from the chat configuration.
 *
 * @since 0.1.0
 *
 * @param key - The configuration key.
 * @returns The configuration value, or undefined.
 */
export declare function useChatbotConfig<K extends keyof ChatbotConfig>(key: K): ChatbotConfig[K] | undefined;
export {};
//# sourceMappingURL=config.d.ts.map