<?php
/**
 * Abilities API Library Initialization
 *
 * @package WordPress\AbilitiesAPI
 * @since 0.1.0
 */

declare( strict_types = 1 );

// Require the classes if not using Composer autoloading
if ( ! class_exists( 'WordPress\AbilitiesAPI\WP_Ability' ) ) {
	require_once __DIR__ . '/WP_Ability.php';
}

if ( ! class_exists( 'WordPress\AbilitiesAPI\WP_Abilities_Registry' ) ) {
	require_once __DIR__ . '/WP_Abilities_Registry.php';
}

// Create class aliases for backward compatibility
if ( ! class_exists( 'WP_Ability' ) ) {
	class_alias( 'WordPress\AbilitiesAPI\WP_Ability', 'WP_Ability' );
}

if ( ! class_exists( 'WP_Abilities_Registry' ) ) {
	class_alias( 'WordPress\AbilitiesAPI\WP_Abilities_Registry', 'WP_Abilities_Registry' );
}