/**
 * Renders the loader.
 *
 * @since 0.1.0
 *
 * @returns The component to be rendered.
 */
export default function Loader(): import("react").JSX.Element;
//# sourceMappingURL=loader.d.ts.map