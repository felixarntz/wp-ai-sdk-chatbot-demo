/**
 * External dependencies
 */
import type { SVGProps } from 'react';
type SendIconProps = SVGProps<SVGSVGElement>;
/**
 * Renders the send icon.
 *
 * @since 0.1.0
 *
 * @param props - The component props.
 * @returns The component to be rendered.
 */
export default function SendIcon(props: SendIconProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=send-icon.d.ts.map