import './style.scss';
import { ChatbotMessage as ChatbotMessageType } from '../../types';
type ChatbotProps = {
    /**
     * The route to use for fetching and sending messages.
     */
    messagesRoute: string;
    /**
     * The messages to display in the chatbot.
     */
    messages?: ChatbotMessageType[];
    /**
     * Function to call when the history of messages is updated.
     */
    onUpdateMessages?: (messages: ChatbotMessageType[]) => void;
    /**
     * Function to call when the close button is clicked.
     */
    onClose: () => void;
    /**
     * Class name to use on the chatbot container.
     */
    className?: string;
};
/**
 * Renders the chatbot.
 *
 * @since 0.1.0
 *
 * @param props - Component props.
 * @returns The component to be rendered.
 */
export default function Chatbot(props: ChatbotProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=index.d.ts.map