/**
 * Logs an error message to the console.
 *
 * @since 0.1.0
 *
 * @param error - The error to log.
 */
export default function logError(error: unknown): void;
//# sourceMappingURL=log-error.d.ts.map